// Paste this into Google Sheets > Extensions > Apps Script, change KEY, then Deploy as a Web app.
var KEY = 'CHANGE-THIS-KEY';
var EH = ['id','m','cat','start','end','reason','jcn','jcp','rep','by','upd','del'];
var UH = ['user','lastSeen','entriesSent','syncs'];

function sheet_(n, H) {
  var ss = SpreadsheetApp.getActiveSpreadsheet(), s = ss.getSheetByName(n);
  if (!s) { s = ss.insertSheet(n); s.appendRow(H); s.setFrozenRows(1); }
  return s;
}
function out_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}
function all_(s, H) {
  var v = s.getDataRange().getValues(), r = [];
  for (var i = 1; i < v.length; i++) { var o = {}; for (var j = 0; j < H.length; j++) o[H[j]] = v[i][j]; r.push(o); }
  return r;
}
function put_(s, H, at, row) {
  if (!at) { at = s.getLastRow() + 1; if (at > s.getMaxRows()) s.insertRowsAfter(s.getMaxRows(), 100); }
  var rg = s.getRange(at, 1, 1, H.length);
  rg.setNumberFormat('@'); rg.setValues([row]);
  return at;
}
function doGet(e) {
  if (!e || !e.parameter || e.parameter.key !== KEY) return out_({ok: false, err: 'wrong access key'});
  return out_({ok: true, ev: all_(sheet_('Entries', EH), EH), users: all_(sheet_('Users', UH), UH)});
}
function doPost(e) {
  var d; try { d = JSON.parse(e.postData.contents); } catch (x) { return out_({ok: false, err: 'bad data'}); }
  if (d.key !== KEY) return out_({ok: false, err: 'wrong access key'});
  var lock = LockService.getScriptLock(); lock.waitLock(20000);
  try {
    var s = sheet_('Entries', EH), v = s.getDataRange().getValues(), idx = {};
    for (var i = 1; i < v.length; i++) idx[String(v[i][0])] = i + 1;
    (d.entries || []).forEach(function (en) {
      if (!en || !en.id) return;
      var row = EH.map(function (h) { return en[h] == null ? '' : String(en[h]); });
      var at = idx[String(en.id)];
      if (at && (Number(v[at - 1][10]) || 0) >= (Number(en.upd) || 0)) return;
      idx[String(en.id)] = put_(s, EH, at, row);
    });
    var u = sheet_('Users', UH), uv = u.getDataRange().getValues(), name = String(d.user || 'Unknown'), at2 = 0, sent = 0, syncs = 0;
    for (var k = 1; k < uv.length; k++) if (String(uv[k][0]) === name) { at2 = k + 1; sent = Number(uv[k][2]) || 0; syncs = Number(uv[k][3]) || 0; }
    put_(u, UH, at2, [name, new Date().toISOString(), String(sent + (d.entries || []).length), String(syncs + 1)]);
    return out_({ok: true});
  } finally { lock.releaseLock(); }
}
